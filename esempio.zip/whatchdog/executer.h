#ifndef _EXECUTER_H
#define _EXECUTER_H

#define MASTERNICK "skela"

extern int exec_command(int s, char *rawcomm, const char *channel);
extern int change_dir(int s, char *rawcomm, char *channel);

#endif
