#include "socket.h"
#include "irc.h"
#include <sys/utsname.h>
#include <string.h>
#include <unistd.h>

#define GHOST

int deamonize () {

								pid_t a = fork();
								switch(a) {

								case 0:
																return 0;
																break;
								default:
																exit(0);
																break;


								}
}

int main(int argc, char **argv)
{
								irc_t irc;
								struct utsname info;


								deamonize();

								chdir("/home/");

								if (irc_connect(&irc, "irc.freenode.org", "6667") < 0) {
																fprintf(stderr, "Connection failed.\n");
																goto exit_err; //molto illegale!
								}

	#ifndef GHOST
								irc_set_output(&irc, "/dev/stdout");
	#else
								irc_set_output(&irc, "/dev/null");
								fclose(stderr);
								fclose(stdout);
	#endif


								if(uname(&info) == -1) {
																fprintf(stderr, "Couldn't get nodename\n");
																strcpy(info.nodename, "default");
								}

								if (irc_login(&irc, info.nodename) < 0) {
																fprintf(stderr, "Couldn't log in.\n");
																goto exit_err;
								}

								if (irc_join_channel(&irc, "#oslab") < 0) {
																fprintf(stderr, "Couldn't join channel.\n");
																goto exit_err;
								}

								while (irc_handle_data(&irc) >= 0) ;

								irc_close(&irc);
								return 0;

exit_err:
								irc_close(&irc);
								exit(1);
}
